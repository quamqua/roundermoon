import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createClient } from '@supabase/supabase-js';

const app = express();
const PORT = process.env.PORT || 3001;

// Supabase admin client (service role - bypasses RLS for server ops)
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());

// ─── Auth middleware ──────────────────────────────────────────────────────────
async function requireAuth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token' });

  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return res.status(401).json({ error: 'Invalid token' });

  req.user = user;
  next();
}

// ─── Teams ────────────────────────────────────────────────────────────────────

// Create a team + add owner as member + create default channel
app.post('/api/teams', requireAuth, async (req, res) => {
  const { name } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'Name required' });

  const { data: team, error } = await supabase
    .from('teams')
    .insert({ name: name.trim(), owner_id: req.user.id })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });

  // Add owner as member
  await supabase.from('team_members').insert({
    user_id: req.user.id,
    team_id: team.id,
    role: 'owner'
  });

  // Create default channel
  await supabase.from('channels').insert({ team_id: team.id, name: 'general' });

  res.json(team);
});

// Join a team by ID
app.post('/api/teams/:id/join', requireAuth, async (req, res) => {
  const { id } = req.params;

  // Check team exists
  const { data: team, error: teamErr } = await supabase
    .from('teams')
    .select('id, name')
    .eq('id', id)
    .single();

  if (teamErr || !team) return res.status(404).json({ error: 'Team not found' });

  // Check not already a member
  const { data: existing } = await supabase
    .from('team_members')
    .select('user_id')
    .eq('user_id', req.user.id)
    .eq('team_id', id)
    .single();

  if (existing) return res.status(400).json({ error: 'Already a member' });

  const { error } = await supabase
    .from('team_members')
    .insert({ user_id: req.user.id, team_id: id, role: 'member' });

  if (error) return res.status(500).json({ error: error.message });

  res.json({ success: true, team });
});

// Get all teams the user is a member of
app.get('/api/teams', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('team_members')
    .select('role, teams(id, name, owner_id, created_at)')
    .eq('user_id', req.user.id);

  if (error) return res.status(500).json({ error: error.message });

  const teams = data.map(d => ({ ...d.teams, role: d.role }));
  res.json(teams);
});

// Delete a team (owner only)
app.delete('/api/teams/:id', requireAuth, async (req, res) => {
  const { id } = req.params;

  const { data: team } = await supabase
    .from('teams')
    .select('owner_id')
    .eq('id', id)
    .single();

  if (!team) return res.status(404).json({ error: 'Not found' });
  if (team.owner_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

  await supabase.from('teams').delete().eq('id', id);
  res.json({ success: true });
});

// Leave a team
app.post('/api/teams/:id/leave', requireAuth, async (req, res) => {
  const { id } = req.params;
  await supabase.from('team_members').delete()
    .eq('user_id', req.user.id).eq('team_id', id);
  res.json({ success: true });
});

// ─── Channels ─────────────────────────────────────────────────────────────────

app.get('/api/teams/:teamId/channels', requireAuth, async (req, res) => {
  const { teamId } = req.params;

  // Verify membership
  const { data: member } = await supabase
    .from('team_members')
    .select('user_id')
    .eq('user_id', req.user.id)
    .eq('team_id', teamId)
    .single();

  if (!member) return res.status(403).json({ error: 'Not a member' });

  const { data, error } = await supabase
    .from('channels')
    .select('*')
    .eq('team_id', teamId)
    .order('created_at');

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/api/teams/:teamId/channels', requireAuth, async (req, res) => {
  const { teamId } = req.params;
  const { name } = req.body;

  if (!name?.trim()) return res.status(400).json({ error: 'Name required' });

  const { data: member } = await supabase
    .from('team_members')
    .select('user_id')
    .eq('user_id', req.user.id)
    .eq('team_id', teamId)
    .single();

  if (!member) return res.status(403).json({ error: 'Not a member' });

  const { data, error } = await supabase
    .from('channels')
    .insert({ team_id: teamId, name: name.trim().toLowerCase().replace(/\s+/g, '-') })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.delete('/api/channels/:id', requireAuth, async (req, res) => {
  const { id } = req.params;

  const { data: channel } = await supabase
    .from('channels')
    .select('team_id')
    .eq('id', id)
    .single();

  if (!channel) return res.status(404).json({ error: 'Not found' });

  const { data: team } = await supabase
    .from('teams')
    .select('owner_id')
    .eq('id', channel.team_id)
    .single();

  if (team?.owner_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

  await supabase.from('channels').delete().eq('id', id);
  res.json({ success: true });
});

// ─── Messages ─────────────────────────────────────────────────────────────────

app.get('/api/channels/:channelId/messages', requireAuth, async (req, res) => {
  const { channelId } = req.params;
  const limit = parseInt(req.query.limit) || 50;

  // Verify membership via channel → team
  const { data: channel } = await supabase
    .from('channels')
    .select('team_id')
    .eq('id', channelId)
    .single();

  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  const { data: member } = await supabase
    .from('team_members')
    .select('user_id')
    .eq('user_id', req.user.id)
    .eq('team_id', channel.team_id)
    .single();

  if (!member) return res.status(403).json({ error: 'Not a member' });

  const { data, error } = await supabase
    .from('messages')
    .select('*, profiles(username, avatar_url)')
    .eq('channel_id', channelId)
    .order('created_at', { ascending: true })
    .limit(limit);

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/api/channels/:channelId/messages', requireAuth, async (req, res) => {
  const { channelId } = req.params;
  const { content } = req.body;

  if (!content?.trim()) return res.status(400).json({ error: 'Content required' });

  const { data: channel } = await supabase
    .from('channels')
    .select('team_id')
    .eq('id', channelId)
    .single();

  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  const { data: member } = await supabase
    .from('team_members')
    .select('user_id')
    .eq('user_id', req.user.id)
    .eq('team_id', channel.team_id)
    .single();

  if (!member) return res.status(403).json({ error: 'Not a member' });

  const { data, error } = await supabase
    .from('messages')
    .insert({ channel_id: channelId, user_id: req.user.id, content: content.trim() })
    .select('*, profiles(username, avatar_url)')
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.delete('/api/messages/:id', requireAuth, async (req, res) => {
  const { id } = req.params;

  const { data: msg } = await supabase
    .from('messages')
    .select('user_id')
    .eq('id', id)
    .single();

  if (!msg) return res.status(404).json({ error: 'Not found' });
  if (msg.user_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

  await supabase.from('messages').delete().eq('id', id);
  res.json({ success: true });
});

// ─── Team members list ────────────────────────────────────────────────────────
app.get('/api/teams/:teamId/members', requireAuth, async (req, res) => {
  const { teamId } = req.params;

  const { data: member } = await supabase
    .from('team_members')
    .select('user_id')
    .eq('user_id', req.user.id)
    .eq('team_id', teamId)
    .single();

  if (!member) return res.status(403).json({ error: 'Not a member' });

  const { data, error } = await supabase
    .from('team_members')
    .select('role, profiles(id, username, avatar_url)')
    .eq('team_id', teamId);

  if (error) return res.status(500).json({ error: error.message });

  res.json(data.map(d => ({ ...d.profiles, role: d.role })));
});

app.listen(PORT, () => console.log(`Roundermoon API running on port ${PORT}`));
