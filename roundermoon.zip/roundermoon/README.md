# Roundermoon

Discord-style MVP chat app built with React, Node.js/Express, and Supabase.

## Project Structure

```
roundermoon/
├── client/          # React (Vite) frontend
├── server/          # Node.js + Express backend
├── .env.example     # Environment variable template
└── README.md
```

## Prerequisites

- Node.js 18+
- A Supabase project (free tier works)
- GitHub OAuth app (for auth)

---

## 1. Supabase Setup

### 1.1 Create a Supabase project at https://supabase.com

### 1.2 Run this SQL in the Supabase SQL Editor:

```sql
-- Teams
create table teams (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid references auth.users(id) on delete cascade,
  created_at timestamptz default now()
);

-- Team members
create table team_members (
  user_id uuid references auth.users(id) on delete cascade,
  team_id uuid references teams(id) on delete cascade,
  role text default 'member',
  primary key (user_id, team_id)
);

-- Channels
create table channels (
  id uuid primary key default gen_random_uuid(),
  team_id uuid references teams(id) on delete cascade,
  name text not null,
  created_at timestamptz default now()
);

-- Messages
create table messages (
  id uuid primary key default gen_random_uuid(),
  channel_id uuid references channels(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  content text not null,
  created_at timestamptz default now()
);

-- Profiles (mirrors auth.users for easy access)
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  avatar_url text,
  updated_at timestamptz default now()
);

-- Auto-create profile on signup
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, username, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'user_name', new.raw_user_meta_data->>'name', 'user'),
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- RLS Policies
alter table teams enable row level security;
alter table team_members enable row level security;
alter table channels enable row level security;
alter table messages enable row level security;
alter table profiles enable row level security;

-- Profiles: anyone can read, only owner can update
create policy "Public profiles readable" on profiles for select using (true);
create policy "Users update own profile" on profiles for update using (auth.uid() = id);

-- Teams: only members can see
create policy "Members see team" on teams for select
  using (exists (select 1 from team_members where team_id = teams.id and user_id = auth.uid()));
create policy "Anyone can create team" on teams for insert with check (auth.uid() = owner_id);
create policy "Owner can update team" on teams for update using (auth.uid() = owner_id);
create policy "Owner can delete team" on teams for delete using (auth.uid() = owner_id);

-- Team members
create policy "Members see membership" on team_members for select
  using (exists (select 1 from team_members tm where tm.team_id = team_members.team_id and tm.user_id = auth.uid()));
create policy "Anyone can join" on team_members for insert with check (auth.uid() = user_id);
create policy "Members can leave" on team_members for delete using (auth.uid() = user_id);

-- Channels: members of the team can see
create policy "Members see channels" on channels for select
  using (exists (select 1 from team_members where team_id = channels.team_id and user_id = auth.uid()));
create policy "Members create channels" on channels for insert
  with check (exists (select 1 from team_members where team_id = channels.team_id and user_id = auth.uid()));
create policy "Owner deletes channels" on channels for delete
  using (exists (select 1 from teams where id = channels.team_id and owner_id = auth.uid()));

-- Messages: team members can read/write
create policy "Members read messages" on messages for select
  using (exists (
    select 1 from channels c
    join team_members tm on tm.team_id = c.team_id
    where c.id = messages.channel_id and tm.user_id = auth.uid()
  ));
create policy "Members send messages" on messages for insert
  with check (
    auth.uid() = user_id and
    exists (
      select 1 from channels c
      join team_members tm on tm.team_id = c.team_id
      where c.id = messages.channel_id and tm.user_id = auth.uid()
    )
  );
create policy "Authors delete messages" on messages for delete using (auth.uid() = user_id);

-- Enable realtime for messages
alter publication supabase_realtime add table messages;
```

### 1.3 Enable GitHub OAuth

In Supabase Dashboard → Authentication → Providers → GitHub:
- Enable GitHub
- Add your GitHub OAuth App's Client ID and Secret
- Set callback URL to: `https://your-supabase-project.supabase.co/auth/v1/callback`

In GitHub → Settings → Developer Settings → OAuth Apps → New OAuth App:
- Homepage URL: `http://your-vps-ip` (or domain)
- Callback URL: `https://your-supabase-project.supabase.co/auth/v1/callback`

---

## 2. Local Development

```bash
# Clone and install
git clone <your-repo>
cd roundermoon

# Install server deps
cd server && npm install

# Install client deps
cd ../client && npm install

# Set up env files (see .env.example)
cp .env.example server/.env
cp .env.example client/.env

# Run server (from /server)
npm run dev

# Run client (from /client)
npm run dev
```

---

## 3. VPS Deployment (Ubuntu)

### 3.1 Initial server setup

```bash
# SSH into your VPS
ssh root@your-vps-ip

# Update system
apt update && apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install nginx and pm2
apt install -y nginx
npm install -g pm2

# Install git
apt install -y git
```

### 3.2 Deploy the app

```bash
# Clone your repo
cd /var/www
git clone <your-repo> roundermoon
cd roundermoon

# Install dependencies
cd server && npm install --production
cd ../client && npm install && npm run build
```

### 3.3 Configure environment

```bash
# Server env
cp /var/www/roundermoon/server/.env.example /var/www/roundermoon/server/.env
nano /var/www/roundermoon/server/.env
# Fill in your Supabase values

# Client env (already baked into build, so rebuild after)
nano /var/www/roundermoon/client/.env
cd /var/www/roundermoon/client && npm run build
```

### 3.4 Start server with PM2

```bash
cd /var/www/roundermoon/server
pm2 start index.js --name roundermoon-api
pm2 save
pm2 startup  # Follow the printed command to enable auto-start
```

### 3.5 Configure Nginx

```bash
nano /etc/nginx/sites-available/roundermoon
```

Paste:
```nginx
server {
    listen 80;
    server_name your-domain.com;  # or your VPS IP

    # Serve React frontend
    root /var/www/roundermoon/client/dist;
    index index.html;

    # API proxy
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # SPA fallback
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

```bash
ln -s /etc/nginx/sites-available/roundermoon /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

### 3.6 (Optional) SSL with Certbot

```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

### 3.7 Updates

```bash
cd /var/www/roundermoon
git pull
cd client && npm run build
cd ../server && pm2 restart roundermoon-api
```

---

## Environment Variables

See `.env.example` for all required variables.
