import { useState, useEffect, useRef } from 'react'
import { supabase } from '../lib/supabase'
import { api } from '../lib/api'

function formatTime(ts) {
  const d = new Date(ts)
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function formatDate(ts) {
  const d = new Date(ts)
  const today = new Date()
  if (d.toDateString() === today.toDateString()) return 'Today'
  const yesterday = new Date(today)
  yesterday.setDate(yesterday.getDate() - 1)
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday'
  return d.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })
}

export default function Chat({ channel, user }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(true)
  const bottomRef = useRef(null)
  const inputRef = useRef(null)

  useEffect(() => {
    if (!channel) return

    setLoading(true)
    setMessages([])

    api.get(`/api/channels/${channel.id}/messages`)
      .then(data => {
        setMessages(data)
        setLoading(false)
        scrollToBottom()
      })
      .catch(() => setLoading(false))

    // Realtime subscription
    const sub = supabase
      .channel(`messages:${channel.id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `channel_id=eq.${channel.id}`
      }, async (payload) => {
        // Fetch with profile
        const { data } = await supabase
          .from('messages')
          .select('*, profiles(username, avatar_url)')
          .eq('id', payload.new.id)
          .single()
        if (data) {
          setMessages(prev => [...prev, data])
          scrollToBottom()
        }
      })
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: 'messages',
        filter: `channel_id=eq.${channel.id}`
      }, (payload) => {
        setMessages(prev => prev.filter(m => m.id !== payload.old.id))
      })
      .subscribe()

    inputRef.current?.focus()

    return () => supabase.removeChannel(sub)
  }, [channel?.id])

  function scrollToBottom() {
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50)
  }

  async function sendMessage(e) {
    e.preventDefault()
    if (!input.trim()) return
    const content = input.trim()
    setInput('')
    try {
      await api.post(`/api/channels/${channel.id}/messages`, { content })
    } catch (err) {
      setInput(content)
      alert(err.message)
    }
  }

  async function deleteMessage(id) {
    try {
      await api.delete(`/api/messages/${id}`)
    } catch (err) {
      alert(err.message)
    }
  }

  if (!channel) {
    return (
      <div className="chat-empty">
        <span>◑</span>
        <p>Select a channel to start chatting</p>
      </div>
    )
  }

  // Group messages by date
  const grouped = []
  let lastDate = null
  for (const msg of messages) {
    const date = formatDate(msg.created_at)
    if (date !== lastDate) {
      grouped.push({ type: 'divider', date })
      lastDate = date
    }
    grouped.push({ type: 'message', msg })
  }

  return (
    <div className="chat">
      <div className="chat-messages">
        {loading ? (
          <div className="chat-loading">Loading messages…</div>
        ) : messages.length === 0 ? (
          <div className="chat-start">
            <div className="chat-start-icon">#</div>
            <h3>Welcome to #{channel.name}</h3>
            <p>This is the beginning of the #{channel.name} channel.</p>
          </div>
        ) : (
          grouped.map((item, i) =>
            item.type === 'divider' ? (
              <div key={`d-${i}`} className="date-divider">
                <span>{item.date}</span>
              </div>
            ) : (
              <MessageItem
                key={item.msg.id}
                msg={item.msg}
                isOwn={item.msg.user_id === user?.id}
                onDelete={deleteMessage}
              />
            )
          )
        )}
        <div ref={bottomRef} />
      </div>

      <form className="chat-input-bar" onSubmit={sendMessage}>
        <input
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={`Message #${channel.name}`}
          autoComplete="off"
          maxLength={2000}
        />
        <button type="submit" disabled={!input.trim()}>Send</button>
      </form>
    </div>
  )
}

function MessageItem({ msg, isOwn, onDelete }) {
  const [hover, setHover] = useState(false)
  const username = msg.profiles?.username || 'Unknown'
  const avatar = msg.profiles?.avatar_url

  return (
    <div
      className="message"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div className="message-avatar">
        {avatar
          ? <img src={avatar} alt={username} />
          : <div className="avatar-placeholder">{username.charAt(0).toUpperCase()}</div>
        }
      </div>
      <div className="message-body">
        <div className="message-meta">
          <span className="message-author">{username}</span>
          <span className="message-time">{formatTime(msg.created_at)}</span>
        </div>
        <p className="message-content">{msg.content}</p>
      </div>
      {isOwn && hover && (
        <button className="delete-msg-btn" onClick={() => onDelete(msg.id)} title="Delete">✕</button>
      )}
    </div>
  )
}
