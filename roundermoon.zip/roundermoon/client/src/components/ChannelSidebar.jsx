import { useState } from 'react'
import { api } from '../lib/api'

export default function ChannelSidebar({ team, channels, activeChannel, onSelectChannel, onChannelsChange, user }) {
  const [showAdd, setShowAdd] = useState(false)
  const [channelName, setChannelName] = useState('')
  const [error, setError] = useState('')

  const isOwner = team?.owner_id === user?.id

  async function createChannel(e) {
    e.preventDefault()
    setError('')
    try {
      await api.post(`/api/teams/${team.id}/channels`, { name: channelName })
      setChannelName('')
      setShowAdd(false)
      onChannelsChange()
    } catch (err) {
      setError(err.message)
    }
  }

  async function deleteChannel(channelId, e) {
    e.stopPropagation()
    if (!confirm('Delete this channel?')) return
    try {
      await api.delete(`/api/channels/${channelId}`)
      onChannelsChange()
    } catch (err) {
      alert(err.message)
    }
  }

  if (!team) return <div className="channel-sidebar empty">Select a team</div>

  return (
    <div className="channel-sidebar">
      <div className="channel-header">
        <span className="channel-label">CHANNELS</span>
        {isOwner && (
          <button className="add-channel-btn" onClick={() => setShowAdd(!showAdd)} title="Add channel">+</button>
        )}
      </div>

      {showAdd && (
        <form className="add-channel-form" onSubmit={createChannel}>
          <input
            value={channelName}
            onChange={e => setChannelName(e.target.value)}
            placeholder="channel-name"
            autoFocus
            required
          />
          {error && <p className="form-error">{error}</p>}
          <div className="modal-actions">
            <button type="button" className="btn-secondary sm" onClick={() => setShowAdd(false)}>✕</button>
            <button type="submit" className="btn-primary sm">Add</button>
          </div>
        </form>
      )}

      <div className="channel-list">
        {channels.map(ch => (
          <div
            key={ch.id}
            className={`channel-item ${activeChannel?.id === ch.id ? 'active' : ''}`}
            onClick={() => onSelectChannel(ch)}
          >
            <span className="channel-hash">#</span>
            <span className="channel-name">{ch.name}</span>
            {isOwner && channels.length > 1 && (
              <button
                className="delete-channel-btn"
                onClick={e => deleteChannel(ch.id, e)}
                title="Delete channel"
              >✕</button>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
