import { useState } from 'react'
import { api } from '../lib/api'

export default function TeamSidebar({ teams, activeTeam, onSelectTeam, onTeamsChange, user }) {
  const [showCreate, setShowCreate] = useState(false)
  const [showJoin, setShowJoin] = useState(false)
  const [teamName, setTeamName] = useState('')
  const [joinId, setJoinId] = useState('')
  const [error, setError] = useState('')

  async function createTeam(e) {
    e.preventDefault()
    setError('')
    try {
      const team = await api.post('/api/teams', { name: teamName })
      setTeamName('')
      setShowCreate(false)
      onTeamsChange()
      onSelectTeam(team)
    } catch (err) {
      setError(err.message)
    }
  }

  async function joinTeam(e) {
    e.preventDefault()
    setError('')
    try {
      const { team } = await api.post(`/api/teams/${joinId.trim()}/join`)
      setJoinId('')
      setShowJoin(false)
      onTeamsChange()
      onSelectTeam(team)
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <aside className="team-sidebar">
      <div className="sidebar-logo">
        <span className="logo-moon">◑</span>
      </div>

      <div className="team-list">
        {teams.map(team => (
          <button
            key={team.id}
            className={`team-icon ${activeTeam?.id === team.id ? 'active' : ''}`}
            onClick={() => onSelectTeam(team)}
            title={team.name}
          >
            {team.name.charAt(0).toUpperCase()}
          </button>
        ))}
      </div>

      <div className="sidebar-actions">
        <button className="team-icon add-btn" onClick={() => { setShowCreate(true); setShowJoin(false); setError('') }} title="Create team">+</button>
        <button className="team-icon join-btn" onClick={() => { setShowJoin(true); setShowCreate(false); setError('') }} title="Join team">#</button>
      </div>

      {(showCreate || showJoin) && (
        <div className="sidebar-modal-overlay" onClick={() => { setShowCreate(false); setShowJoin(false); setError('') }}>
          <div className="sidebar-modal" onClick={e => e.stopPropagation()}>
            {showCreate ? (
              <>
                <h3>Create Team</h3>
                <form onSubmit={createTeam}>
                  <input
                    value={teamName}
                    onChange={e => setTeamName(e.target.value)}
                    placeholder="Team name"
                    autoFocus
                    required
                  />
                  {error && <p className="form-error">{error}</p>}
                  <div className="modal-actions">
                    <button type="button" className="btn-secondary" onClick={() => setShowCreate(false)}>Cancel</button>
                    <button type="submit" className="btn-primary">Create</button>
                  </div>
                </form>
              </>
            ) : (
              <>
                <h3>Join Team</h3>
                <p className="modal-hint">Enter the Team ID shared by the team owner.</p>
                <form onSubmit={joinTeam}>
                  <input
                    value={joinId}
                    onChange={e => setJoinId(e.target.value)}
                    placeholder="Team ID (UUID)"
                    autoFocus
                    required
                  />
                  {error && <p className="form-error">{error}</p>}
                  <div className="modal-actions">
                    <button type="button" className="btn-secondary" onClick={() => setShowJoin(false)}>Cancel</button>
                    <button type="submit" className="btn-primary">Join</button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </aside>
  )
}
