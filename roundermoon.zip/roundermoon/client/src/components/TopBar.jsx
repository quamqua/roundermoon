import { useState } from 'react'
import { api } from '../lib/api'

export default function TopBar({ team, channel, user, onLeave, onDelete }) {
  const [showSettings, setShowSettings] = useState(false)
  const [showMembers, setShowMembers] = useState(false)
  const [members, setMembers] = useState([])

  const isOwner = team?.owner_id === user?.id

  async function loadMembers() {
    const data = await api.get(`/api/teams/${team.id}/members`)
    setMembers(data)
    setShowMembers(true)
  }

  async function handleLeave() {
    if (!confirm(`Leave "${team.name}"?`)) return
    await api.post(`/api/teams/${team.id}/leave`)
    onLeave()
  }

  async function handleDelete() {
    if (!confirm(`Delete "${team.name}" and all its data?`)) return
    await api.delete(`/api/teams/${team.id}`)
    onDelete()
  }

  function copyId() {
    navigator.clipboard.writeText(team.id)
    alert('Team ID copied! Share it so others can join.')
  }

  return (
    <header className="topbar">
      <div className="topbar-left">
        {channel ? (
          <>
            <span className="topbar-hash">#</span>
            <span className="topbar-channel">{channel.name}</span>
          </>
        ) : team ? (
          <span className="topbar-team">{team.name}</span>
        ) : (
          <span className="topbar-placeholder">Select a team and channel</span>
        )}
      </div>

      <div className="topbar-right">
        {team && (
          <>
            <button className="topbar-btn" onClick={loadMembers} title="Members">👥</button>
            <button className="topbar-btn" onClick={() => setShowSettings(!showSettings)} title="Settings">⚙️</button>
          </>
        )}
        <div className="topbar-user">
          {user?.user_metadata?.avatar_url && (
            <img className="user-avatar" src={user.user_metadata.avatar_url} alt="avatar" />
          )}
          <span className="user-name">{user?.user_metadata?.user_name || user?.email}</span>
        </div>
      </div>

      {showSettings && team && (
        <div className="dropdown settings-dropdown">
          <div className="dropdown-header">
            <strong>{team.name}</strong>
            <button className="dropdown-close" onClick={() => setShowSettings(false)}>✕</button>
          </div>
          <div className="dropdown-item" onClick={copyId}>
            📋 Copy Team ID (for invites)
          </div>
          {!isOwner && (
            <div className="dropdown-item danger" onClick={handleLeave}>
              🚪 Leave Team
            </div>
          )}
          {isOwner && (
            <div className="dropdown-item danger" onClick={handleDelete}>
              🗑️ Delete Team
            </div>
          )}
        </div>
      )}

      {showMembers && (
        <div className="modal-overlay" onClick={() => setShowMembers(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Members — {team.name}</h3>
              <button onClick={() => setShowMembers(false)}>✕</button>
            </div>
            <div className="members-list">
              {members.map(m => (
                <div key={m.id} className="member-item">
                  {m.avatar_url && <img className="member-avatar" src={m.avatar_url} alt="" />}
                  <span className="member-name">{m.username}</span>
                  <span className={`member-role ${m.role}`}>{m.role}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
