import { useState, useEffect, useCallback } from 'react'
import { useAuth } from './hooks/useAuth'
import { api } from './lib/api'
import Login from './pages/Login'
import TeamSidebar from './components/TeamSidebar'
import ChannelSidebar from './components/ChannelSidebar'
import TopBar from './components/TopBar'
import Chat from './components/Chat'

export default function App() {
  const { user, loading, signOut } = useAuth()
  const [teams, setTeams] = useState([])
  const [activeTeam, setActiveTeam] = useState(null)
  const [channels, setChannels] = useState([])
  const [activeChannel, setActiveChannel] = useState(null)

  const loadTeams = useCallback(async () => {
    if (!user) return
    const data = await api.get('/api/teams')
    setTeams(data)
  }, [user])

  const loadChannels = useCallback(async () => {
    if (!activeTeam) return
    const data = await api.get(`/api/teams/${activeTeam.id}/channels`)
    setChannels(data)
    setActiveChannel(prev => data.find(c => c.id === prev?.id) || data[0] || null)
  }, [activeTeam])

  useEffect(() => { loadTeams() }, [loadTeams])
  useEffect(() => { loadChannels() }, [loadChannels])

  function handleSelectTeam(team) {
    setActiveTeam(team)
    setActiveChannel(null)
    setChannels([])
  }

  function handleLeaveOrDelete() {
    setActiveTeam(null)
    setActiveChannel(null)
    setChannels([])
    loadTeams()
  }

  if (loading) return <div className="fullscreen-center"><span className="logo-moon spin">◑</span></div>
  if (!user) return <Login />

  return (
    <div className="app-layout">
      <TeamSidebar
        teams={teams}
        activeTeam={activeTeam}
        onSelectTeam={handleSelectTeam}
        onTeamsChange={loadTeams}
        user={user}
      />

      <div className="main-panel">
        <div className="left-panel">
          <div className="team-name-header">
            {activeTeam ? (
              <>
                <span className="team-name-text">{activeTeam.name}</span>
                <button className="signout-btn" onClick={signOut} title="Sign out">↪</button>
              </>
            ) : (
              <span className="team-name-placeholder">No team selected</span>
            )}
          </div>
          <ChannelSidebar
            team={activeTeam}
            channels={channels}
            activeChannel={activeChannel}
            onSelectChannel={setActiveChannel}
            onChannelsChange={loadChannels}
            user={user}
          />
        </div>

        <div className="right-panel">
          <TopBar
            team={activeTeam}
            channel={activeChannel}
            user={user}
            onLeave={handleLeaveOrDelete}
            onDelete={handleLeaveOrDelete}
          />
          <Chat channel={activeChannel} user={user} />
        </div>
      </div>
    </div>
  )
}
